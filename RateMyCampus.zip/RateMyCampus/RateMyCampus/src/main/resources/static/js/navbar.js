// Mobile menu toggle
       const mobileToggle = document.querySelector('.mobile-menu-toggle');
       const navLinks = document.querySelector('.nav-links');

       mobileToggle.addEventListener('click', () => {
           navLinks.classList.toggle('active');
           mobileToggle.classList.toggle('active');
       });

       // Smooth scroll and interactive effects
       document.querySelectorAll('.college-card').forEach(card => {
           card.addEventListener('mouseenter', () => {
               card.style.transform = 'translateY(-10px) scale(1.02)';
           });
           
           card.addEventListener('mouseleave', () => {
               card.style.transform = 'translateY(0) scale(1)';
           });
       });