$(document).ready(function() {
    // Function to create a college card HTML
    function createCollegeCard(college) {
        var collegeData = {
            imageUrl: `/image/${college.cimg}`, // Replace with actual image logic if available
            name: college.cname || 'Unknown College',
            location: college.address || 'Unknown Location',
            rating: 'N/A', // Placeholder, will be updated with AJAX
            studentCount: 'N/A', // Placeholder, will be updated with AJAX
            reviewCount: 'N/A', // Placeholder, will be updated with AJAX
     
        };

        return `
            <div class="college-card" data-id="${college.cid}">
                <div class="card-image">
                    <img src="${collegeData.imageUrl}" alt="${collegeData.name} Campus">
                    <div class="rating-badge">
                        <i class="fas fa-star"></i>
                        <span class="rating-value">${collegeData.rating}</span>
                    </div>
                </div>
                <div class="card-content">
                    <h3 class="college-name">${collegeData.name}</h3>
                    <p class="college-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${collegeData.location}
                    </p>
                    <div class="college-stats">
                        <div class="stat">
                            <span class="stat-value" data-field="studentCount">${collegeData.studentCount}</span>
                            <span class="stat-label">Students</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value" data-field="reviewCount">${collegeData.reviewCount}</span>
                            <span class="stat-label">Reviews</span>
                        </div>
                        
                    </div>
					<a href="/college-detail/1" class="view-details-btn">
					                            <span>View Details</span>
					                            <i class="fas fa-arrow-right"></i>
					              </a>
                </div>
            </div>
        `;
    }

    // Function to fetch and update rating for a single college card
	function updateCollegeRating(cardElement, collegeId) {
	    $.ajax({
	        url: `/api/colleges/${collegeId}/ratings`,
	        method: 'GET',
	        dataType: 'json',
	        success: function(ratingData) {
	            console.log(ratingData); // This will show you the array
	            // Check if ratingData is an array and has at least one element
	            if (Array.isArray(ratingData) && ratingData.length > 0) {
	                // Access the score from the first object in the array
	                var rating = ratingData[0].score;
	                // If score is a valid number, update the card
	                if (typeof rating === 'number') {
	                    cardElement.find('.rating-value').text(rating);
	                } else {
	                    cardElement.find('.rating-value').text('N/A');
	                }
	            } else {
	                cardElement.find('.rating-value').text('N/A');
	            }
	        },
	        error: function(xhr, status, error) {
	            console.error(`Error fetching rating for college ${collegeId}:`, error);
	            cardElement.find('.rating-value').text('N/A');
	        }
	    });
	}
    // Function to fetch and update student count and rating count
    function updateCollegeCounts(cardElement, collegeId) {
        // Fetch student count
        $.ajax({
            url: `/api/colleges/${collegeId}/student-count`,
            method: 'GET',
            dataType: 'json',
            success: function(studentCount) {
                cardElement.find('[data-field="studentCount"]').text(studentCount);
            },
            error: function(xhr, status, error) {
                console.error(`Error fetching student count for college ${collegeId}:`, error);
                cardElement.find('[data-field="studentCount"]').text('N/A');
            }
        });

        // Fetch rating count (reviews)
        $.ajax({
            url: `/api/colleges/${collegeId}/rating-count`,
            method: 'GET',
            dataType: 'json',
            success: function(ratingCount) {
                cardElement.find('[data-field="reviewCount"]').text(ratingCount);
            },
            error: function(xhr, status, error) {
                console.error(`Error fetching rating count for college ${collegeId}:`, error);
                cardElement.find('[data-field="reviewCount"]').text('N/A');
            }
        });
    }

    // AJAX request to fetch colleges
    $.ajax({
        url: '/api/colleges',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
         
            const collegesGrid = $('#colleges-grid');
            collegesGrid.empty(); // Clear any existing content
            if (data && data.length > 0) {
                data.forEach(college => {
                    var cardHtml = createCollegeCard(college);
                    collegesGrid.append(cardHtml);
                    var cardElement = collegesGrid.find(`[data-id="${college.cid}"]`);
                    updateCollegeRating(cardElement, college.cid);
                    updateCollegeCounts(cardElement, college.cid);
                });
            } else {
                collegesGrid.append('<p>No colleges found.</p>');
            }
        },
        error: function(xhr, status, error) {
            console.error('Error fetching colleges:', error);
            $('#colleges-grid').append('<p>Error loading colleges. Please try again later.</p>');
        }
    });
});