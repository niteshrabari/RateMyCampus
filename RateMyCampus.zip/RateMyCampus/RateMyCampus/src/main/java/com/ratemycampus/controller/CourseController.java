package com.ratemycampus.controller;

import com.ratemycampus.entity.Course;
import com.ratemycampus.service.CourseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping
    public ResponseEntity<?> createCourse(@Valid @RequestBody Course course,BindingResult result) {
    	 try {
         	
     		if (result.hasErrors()) {
     	        HashMap<String, String> errors = new HashMap<>();
     	        result.getFieldErrors().forEach(error -> {
     	            errors.put(error.getField(), error.getDefaultMessage());
     	
     	        });
     	
     	        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
     	 }
     	
         Course saved = courseService.addCourse(course);
         return new ResponseEntity<>(saved, HttpStatus.CREATED);
     } catch (RuntimeException e) {
     	HashMap<String, String> errors = new HashMap<>();
         errors.put("error", e.getMessage());
         return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
     }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Course> updateCourse(@PathVariable Integer id, @Valid @RequestBody Course course) {
        return ResponseEntity.ok(courseService.updateCourse(id, course));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCourse(@PathVariable Integer id) {
        courseService.deleteCourse(id);
        return ResponseEntity.ok("Course deleted successfully");
    }

    @GetMapping("/{id}")
    public ResponseEntity<Course> getCourseById(@PathVariable Integer id) {
        return ResponseEntity.ok(courseService.getCourseById(id));
    }

    @GetMapping
    public ResponseEntity<List<Course>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }
}
