package com.ratemycampus.config;

import com.ratemycampus.security.JwtFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
            	    // Public (read-only) endpoints
            	    .requestMatchers("/auth/**").permitAll()
            	    .requestMatchers("/api/colleges/search").permitAll()
            	    .requestMatchers("/api/colleges/city/**").permitAll()
            	    .requestMatchers("/api/colleges/{id}/departments").permitAll()
            	    .requestMatchers("/api/colleges/{id}/ratings").permitAll()
            	    .requestMatchers("/api/colleges/{id}/rating-count").permitAll()
            	    .requestMatchers("/api/colleges/{id}/student-count").permitAll()
            	    .requestMatchers(HttpMethod.GET, "/api/colleges/**").permitAll()

            	    // Protected endpoints
            	    .requestMatchers(HttpMethod.POST, "/api/colleges/addcollege").hasAuthority("ROLE_ADMIN")
            	    .requestMatchers(HttpMethod.DELETE, "/api/colleges/{id}").hasAuthority("ROLE_ADMIN")
            	    .requestMatchers(HttpMethod.PUT, "/api/colleges/updateCollegeImage/{id}").hasAuthority("ROLE_COLLEGE_ADMIN")

            	    .anyRequest().authenticated()
            	)


            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }


}