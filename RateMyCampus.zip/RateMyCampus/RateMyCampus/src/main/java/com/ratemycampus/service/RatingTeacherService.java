package com.ratemycampus.service;

import com.ratemycampus.entity.College;
import com.ratemycampus.entity.Rating;
import com.ratemycampus.entity.RatingTeacher;
import com.ratemycampus.entity.Student;
import com.ratemycampus.entity.Teacher;
import com.ratemycampus.repository.CollegeRepository;
import com.ratemycampus.repository.RatingTeacherRepository;
import com.ratemycampus.repository.StudentRepository;
import com.ratemycampus.repository.TeacherRepository;

import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ratemycampus.entity.RatingTeacher;

import java.util.List;

@Service
public class RatingTeacherService {

    @Autowired
    private RatingTeacherRepository ratingTeacherRepository ;
    
    @Autowired
    private TeacherRepository teacheRepository;
    
    @Autowired
    private StudentRepository studentRepository;

    public RatingTeacher addRating(RatingTeacher rating) {
        if (rating.getTeacher() == null || rating.getStudent() == null) {
            throw new IllegalArgumentException("College and Student must not be null");
        }

        Integer TeacherId = rating.getTeacher().getTid();
        Integer studentId = rating.getStudent().getSid();

        Teacher teacher = teacheRepository.findById(TeacherId)
                .orElseThrow(() -> new EntityNotFoundException("Teacher not found with ID: " + TeacherId));

        Student student = studentRepository.findBySid(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with ID: " + studentId));

        // Prevent duplicate rating by same student for same college
        if (ratingTeacherRepository.existsByTeacher_TidAndStudent_Sid(TeacherId, studentId)) {
            throw new IllegalStateException("Rating already exists for this student and college.");
        }

        rating.setTeacher(teacher);
        rating.setStudent(student);
        return ratingTeacherRepository.save(rating);
    }

    public List<RatingTeacher> getAllRatings() {
        return ratingTeacherRepository.findAll();
    }

    public RatingTeacher getRatingById(Long id) {
        return ratingTeacherRepository.findById(id).orElseThrow(() -> new RuntimeException("Rating not found"));
    }

    public List<RatingTeacher> getRatingsByTeacherId(Long teacherId) {
        return ratingTeacherRepository.findByTeacherTid(teacherId);
    }

    public List<RatingTeacher> getRatingsByStudentId(Long studentId) {
        return ratingTeacherRepository.findByStudentSid(studentId);
    }

    public void deleteRating(Long id) {
        ratingTeacherRepository.deleteById(id);
    }
    public RatingTeacher updateRating(Long id, RatingTeacher rating) {
        RatingTeacher existing = getRatingById(id);
        existing.setScore(rating.getScore());
        return ratingTeacherRepository.save(existing);
    }
}
