package com.ratemycampus.dto;

public class CollegeDTO {
	public Long cid;
	public String cname;
	public String cdesc;
	public String cactivity;
	public String address;
	public String cimg;
	public String email;
}


