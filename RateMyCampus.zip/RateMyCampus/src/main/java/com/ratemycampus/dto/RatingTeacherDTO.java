package com.ratemycampus.dto;

public class RatingTeacherDTO {
	public Long id;
	public int score;
	public Integer teacherId;
	public Integer studentId;
	public Integer courseId;
}


