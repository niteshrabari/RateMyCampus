package com.ratemycampus.dto;

public class TeacherDTO {
	public Integer tid;
	public String tname;
	public Integer tsem;
	public String tsection;
	public String timg;
	public Long collegeId;
	public Long departmentId;
}


