package com.ratemycampus.dto;

public class CourseDTO {
	public Integer c_id;
	public String cName;
	public Integer cDuration;
	public Integer cSince;
	public Long collegeId;
	public Long departmentId;
}


