package com.ratemycampus.dto;

public class CollegeAdminDTO {
	public Integer id;
	public String name;
	public String email;
	public String mobile;
	public String imagePath;
	public Long collegeId;
}


