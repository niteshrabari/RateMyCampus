package com.ratemycampus.dto;

public class RatingDTO {
	public Long id;
	public int score;
	public Long collegeId;
	public Integer studentId;
}


