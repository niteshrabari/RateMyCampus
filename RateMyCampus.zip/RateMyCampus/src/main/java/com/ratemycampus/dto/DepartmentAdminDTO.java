package com.ratemycampus.dto;

public class DepartmentAdminDTO {
	public Integer hodId;
	public String username;
	public String name;
	public String email;
	public String daImg;
	public Long departmentId;
	public Long collegeId;
}


