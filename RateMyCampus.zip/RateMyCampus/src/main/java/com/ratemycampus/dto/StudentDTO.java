package com.ratemycampus.dto;

public class StudentDTO {
	public Integer sid;
	public String enrollment;
	public String sname;
	public Integer ssem;
	public String ssection;
	public String sgender;
	public String smobile;
	public String scity;
	public String simg;
	public String semail;
	public Long collegeId;
	public Long departmentId;
	public Integer courseId;
}


