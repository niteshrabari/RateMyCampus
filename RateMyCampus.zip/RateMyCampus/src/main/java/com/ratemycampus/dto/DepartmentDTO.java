package com.ratemycampus.dto;

public class DepartmentDTO {
	public Long deptId;
	public String deptName;
	public String desc;
	public Long collegeId;
}


