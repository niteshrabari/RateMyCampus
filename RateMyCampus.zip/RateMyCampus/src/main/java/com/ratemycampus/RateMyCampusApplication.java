package com.ratemycampus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateMyCampusApplication {

	public static void main(String[] args) {
		SpringApplication.run(RateMyCampusApplication.class, args);
	}

}
